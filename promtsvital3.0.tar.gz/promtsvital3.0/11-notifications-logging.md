# Шаг 11. Система уведомлений и логирования

## Требования
- Push-уведомления о важных событиях
- Журнал действий врача (audit log)
- Уведомления об истечении сессии
- Система алертов при критических показателях

## Компоненты
- NotificationCenter
- ToastNotifications
- AuditLogger
- SessionTimeoutWarning

## API endpoints
- GET /api/v3/notifications
- POST /api/v3/notifications/mark-read
- GET /api/v3/audit-logs

## Примечания
- Без спама уведомлениями
- Критичные уведомления — всплывающие
- Обычные — в центре уведомлений