# Paso 9. Layout Adaptativo para Todos los Dispositivos

## Requisitos
- Soporte para desktop, tablet, mobile
- Sidebar — se colapsa en móviles
- TopBar — adaptativo
- Indicador de tipo de dispositivo
- UI touch-friendly
- Estilo glassmorphism oscuro

## Breakpoints Responsive
```css
/* Mobile First Approach */
.container {
  /* Mobile: <768px */
  width: 100%;
  padding: 1rem;
}

/* Tablet: 768px-1024px */
@media (min-width: 768px) {
  .container {
    padding: 1.5rem;
  }
}

/* Desktop: >1024px */
@media (min-width: 1024px) {
  .container {
    max-width: 1200px;
    padding: 2rem;
  }
}
```

## Ejemplo de Uso
```tsx
<ResponsiveLayout
  sidebar={<Sidebar />}
  topbar={<TopBar />}
  device={deviceType}
>
  {children}
</ResponsiveLayout>
```

## Componentes Adaptativos

### Sidebar
```tsx
interface SidebarProps {
  isCollapsed: boolean;
  device: 'mobile' | 'tablet' | 'desktop';
  onToggle: () => void;
}

// Estados por dispositivo:
// Mobile: Overlay drawer
// Tablet: Collapsible sidebar
// Desktop: Fixed sidebar
```

### TopBar
```tsx
interface TopBarProps {
  showMenuButton: boolean; // Solo en mobile/tablet
  showFullSearch: boolean; // Solo en desktop
  compact: boolean;        // Para tablet
}
```

### DeviceIndicator
```tsx
<DeviceIndicator 
  type={deviceType}
  orientation={orientation}
>
  📱 Mobile Portrait
</DeviceIndicator>
```

## Layout por Dispositivo

### Mobile (<768px)
```
┌─────────────────┐
│ [☰] VITAL [🔍] │ <- Header compacto
├─────────────────┤
│                 │
│   Contenido     │
│   Principal     │
│   (Stack)       │
│                 │
├─────────────────┤
│ [Estado] [Lang] │ <- Footer mínimo
└─────────────────┘
```

### Tablet (768px-1024px)
```
┌───────────────────────────┐
│ [☰] VITAL   [🔍 Buscar]  │ <- Header medio
├─────┬─────────────────────┤
│ S   │                     │
│ i   │    Contenido        │
│ d   │    Principal        │
│ e   │                     │
│     │                     │
├─────┴─────────────────────┤
│ [Autoguardado] [ES|CA|FR] │ <- Footer completo
└───────────────────────────┘
```

### Desktop (>1024px)
```
┌─────────────────────────────────────────┐
│ VITAL 3.0    [🔍 Búsqueda] [Perfil] [Lang] │ <- Header completo
├─────────┬───────────────────────────────┤
│ Sidebar │        Contenido Principal    │
│ Completo│                               │
│ • Menú  │                               │
│ • Acc   │                               │
│ • Pac   │                               │
│ • Plant │                               │
├─────────┴───────────────────────────────┤
│ [Autoguardado: 3s] [Estado] [Versión]   │ <- Footer detallado
└─────────────────────────────────────────┘
```

## Hooks Utilitarios
```typescript
// Detectar dispositivo
const useDevice = () => {
  const [device, setDevice] = useState<DeviceType>('desktop');
  
  useEffect(() => {
    const updateDevice = () => {
      const width = window.innerWidth;
      if (width < 768) setDevice('mobile');
      else if (width < 1024) setDevice('tablet');
      else setDevice('desktop');
    };
    
    updateDevice();
    window.addEventListener('resize', updateDevice);
    return () => window.removeEventListener('resize', updateDevice);
  }, []);
  
  return device;
};

// Detectar orientación
const useOrientation = () => {
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  
  useEffect(() => {
    const updateOrientation = () => {
      setOrientation(window.innerHeight > window.innerWidth ? 'portrait' : 'landscape');
    };
    
    updateOrientation();
    window.addEventListener('resize', updateOrientation);
    return () => window.removeEventListener('resize', updateOrientation);
  }, []);
  
  return orientation;
};
```

## Gestos Touch (Mobile/Tablet)
- **Swipe Right:** Abrir sidebar
- **Swipe Left:** Cerrar sidebar  
- **Pull to Refresh:** Actualizar datos
- **Long Press:** Menú contextual

## Optimizaciones de Performance
- **Lazy Loading:** Componentes pesados cargados bajo demanda
- **Virtual Scrolling:** Para listas largas en mobile
- **Image Optimization:** Responsive images
- **Bundle Splitting:** Código separado por dispositivo

## Notas
- Todo debe funcionar igual de bien en todos los dispositivos
- Prioridad: experiencia móvil primero
- Navegación consistente entre dispositivos
- Accesibilidad completa (ARIA, keyboard navigation)