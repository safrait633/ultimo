# Paso 18. Testing y QA Automatizado

## 🧪 Estrategia de Testing

### Pirámide de Testing
```
     /\
    /  \     E2E Tests (5%)
   /____\    Integration Tests (15%)
  /______\   Unit Tests (80%)
 /________\
```

### Tipos de Tests
- **Unit Tests:** Funciones y componentes individuales
- **Integration Tests:** Interacción entre componentes
- **E2E Tests:** Flujos completos de usuario
- **Visual Tests:** Regresión visual de UI
- **Performance Tests:** Tiempo de carga y responsividad

## 🔬 Unit Tests (Jest + React Testing Library)

### Ejemplo: Componente PatientCard
```typescript
// __tests__/components/PatientCard.test.tsx
import { render, screen } from '@testing-library/react';
import { PatientCard } from '../PatientCard';

describe('PatientCard', () => {
  const mockPatient = {
    id: 1,
    firstName: 'Juan',
    lastName: 'Pérez',
    age: 45,
    gender: 'male'
  };

  it('muestra información del paciente correctamente', () => {
    render(<PatientCard patient={mockPatient} />);
    
    expect(screen.getByText('Juan Pérez')).toBeInTheDocument();
    expect(screen.getByText('45 años')).toBeInTheDocument();
    expect(screen.getByText('Masculino')).toBeInTheDocument();
  });

  it('maneja pacientes sin edad', () => {
    const patientWithoutAge = { ...mockPatient, age: undefined };
    render(<PatientCard patient={patientWithoutAge} />);
    
    expect(screen.getByText('Edad no especificada')).toBeInTheDocument();
  });
});
```

### Ejemplo: Hook usePatientSearch
```typescript
// __tests__/hooks/usePatientSearch.test.ts
import { renderHook, waitFor } from '@testing-library/react';
import { usePatientSearch } from '../usePatientSearch';

describe('usePatientSearch', () => {
  it('debería buscar pacientes correctamente', async () => {
    const { result } = renderHook(() => usePatientSearch());
    
    act(() => {
      result.current.search('Juan');
    });
    
    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
      expect(result.current.results).toHaveLength(2);
    });
  });
});
```

## 🔗 Integration Tests

### Ejemplo: Flujo de Creación de Paciente
```typescript
// __tests__/integration/patient-creation.test.tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { PatientCreationFlow } from '../PatientCreationFlow';

describe('Flujo de Creación de Paciente', () => {
  it('crea paciente completo correctamente', async () => {
    const user = userEvent.setup();
    render(<PatientCreationFlow />);
    
    // Llenar formulario
    await user.type(screen.getByLabelText('Nombre'), 'María');
    await user.type(screen.getByLabelText('Apellido'), 'González');
    await user.type(screen.getByLabelText('Edad'), '32');
    await user.selectOptions(screen.getByLabelText('Género'), 'female');
    
    // Enviar formulario
    await user.click(screen.getByRole('button', { name: /crear paciente/i }));
    
    // Verificar resultado
    await waitFor(() => {
      expect(screen.getByText('Paciente creado exitosamente')).toBeInTheDocument();
    });
  });
});
```

## 🎭 E2E Tests (Playwright)

### Configuración
```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    video: 'retain-on-failure',
    screenshot: 'only-on-failure'
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] }
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] }
    },
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] }
    }
  ]
});
```

### Ejemplo: Test E2E Completo
```typescript
// e2e/medical-examination-flow.spec.ts
import { test, expect } from '@playwright/test';

test('flujo completo de examen médico', async ({ page }) => {
  // Login
  await page.goto('/');
  await page.fill('[data-testid="email"]', 'doctor@vital.com');
  await page.fill('[data-testid="password"]', 'password123');
  await page.click('[data-testid="login-button"]');
  
  // Verificar dashboard
  await expect(page.locator('h1')).toContainText('Dashboard');
  
  // Crear nuevo examen
  await page.click('[data-testid="new-examination"]');
  
  // Buscar paciente
  await page.fill('[data-testid="patient-search"]', 'Juan Pérez');
  await page.click('[data-testid="patient-result-0"]');
  
  // Seleccionar especialidad
  await page.click('[data-testid="specialty-cardiology"]');
  
  // Llenar formulario
  await page.fill('[data-testid="chief-complaint"]', 'Dolor en el pecho');
  await page.fill('[data-testid="blood-pressure-systolic"]', '140');
  await page.fill('[data-testid="blood-pressure-diastolic"]', '90');
  
  // Guardar examen
  await page.click('[data-testid="save-examination"]');
  
  // Verificar confirmación
  await expect(page.locator('[data-testid="success-message"]'))
    .toContainText('Examen guardado exitosamente');
});
```

## 📊 Tests de Performance

### Configuración Lighthouse CI
```javascript
// lighthouserc.js
module.exports = {
  ci: {
    collect: {
      url: ['http://localhost:3000'],
      numberOfRuns: 3,
    },
    assert: {
      assertions: {
        'categories:performance': ['error', { minScore: 0.8 }],
        'categories:accessibility': ['error', { minScore: 0.9 }],
        'categories:best-practices': ['error', { minScore: 0.8 }],
        'categories:seo': ['error', { minScore: 0.8 }],
      },
    },
    upload: {
      target: 'temporary-public-storage',
    },
  },
};
```

### Tests de Carga de API
```typescript
// __tests__/performance/api-load.test.ts
import { performance } from 'perf_hooks';

describe('Performance de API', () => {
  it('búsqueda de pacientes debe responder en menos de 500ms', async () => {
    const start = performance.now();
    
    const response = await fetch('/api/v3/patients/search?q=test');
    
    const end = performance.now();
    const duration = end - start;
    
    expect(response.status).toBe(200);
    expect(duration).toBeLessThan(500);
  });
});
```

## 🎨 Visual Regression Tests

### Configuración Chromatic
```typescript
// .storybook/main.ts
module.exports = {
  stories: ['../src/**/*.stories.@(js|jsx|ts|tsx)'],
  addons: [
    '@storybook/addon-essentials',
    '@storybook/addon-a11y',
    'chromatic/isChromatic'
  ]
};
```

### Story de Componente
```typescript
// src/components/PatientCard.stories.tsx
import type { Meta, StoryObj } from '@storybook/react';
import { PatientCard } from './PatientCard';

const meta: Meta<typeof PatientCard> = {
  title: 'Components/PatientCard',
  component: PatientCard,
  parameters: {
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    patient: {
      id: 1,
      firstName: 'Juan',
      lastName: 'Pérez',
      age: 45,
      gender: 'male'
    }
  }
};

export const WithoutAge: Story = {
  args: {
    patient: {
      id: 2,
      firstName: 'María',
      lastName: 'González',
      gender: 'female'
    }
  }
};
```

## 🌍 Tests Multiidioma

### Test de Traducciones
```typescript
// __tests__/i18n/translations.test.ts
import i18n from '../i18n';

describe('Traducciones', () => {
  const languages = ['es', 'ca', 'fr', 'en', 'ru'];
  const requiredKeys = ['login', 'register', 'dashboard', 'patient'];
  
  languages.forEach(lang => {
    describe(`Idioma: ${lang}`, () => {
      requiredKeys.forEach(key => {
        it(`debe tener la clave '${key}'`, () => {
          expect(i18n.getResource(lang, 'common', key)).toBeDefined();
        });
      });
    });
  });
});
```

## 🚀 CI/CD Pipeline

### GitHub Actions
```yaml
# .github/workflows/test.yml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run test:unit
      - run: npm run test:integration
      - run: npm run build
      - run: npm run test:e2e
      - run: npm run lighthouse:ci
```