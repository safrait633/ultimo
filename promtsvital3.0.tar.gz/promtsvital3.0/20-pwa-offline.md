# Paso 20. Aplicación Web Progresiva (PWA)

## Requisitos
- Funcionamiento offline básico
- Instalación en dispositivos móviles
- Notificaciones push
- Sincronización cuando vuelva la conexión

## Configuración PWA

```json
// public/manifest.json
{
  "name": "VITAL 3.0 - Plataforma Médica",
  "short_name": "VITAL 3.0",
  "description": "Sistema médico profesional",
  "start_url": "/",
  "display": "standalone",
  "theme_color": "#0066CC",
  "background_color": "#181A20",
  "orientation": "portrait-primary",
  "icons": [
    {
      "src": "/icons/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icons/icon-512.png", 
      "sizes": "512x512",
      "type": "image/png"
    }
  ],
  "categories": ["medical", "health", "productivity"],
  "lang": "es",
  "scope": "/"
}
```

## Service Worker
```typescript
// sw.js - Service Worker
const CACHE_NAME = 'vital-v3.0.0';
const OFFLINE_PAGES = [
  '/',
  '/offline',
  '/dashboard'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(OFFLINE_PAGES))
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method === 'GET') {
    event.respondWith(
      caches.match(event.request)
        .then(response => response || fetch(event.request))
        .catch(() => caches.match('/offline'))
    );
  }
});
```

## Funcionalidad Offline
- **Lectura:** Acceso a datos en cache
- **Escritura:** Cola de sincronización para cuando vuelva internet
- **Notificación:** Indicador de estado offline/online

## Componente OfflineIndicator
```tsx
<OfflineIndicator>
  {isOffline ? (
    <Alert type="warning">
      Modo offline - Los cambios se sincronizarán cuando vuelva la conexión
    </Alert>
  ) : (
    <Alert type="success">
      Conectado - Sincronización automática activa
    </Alert>
  )}
</OfflineIndicator>
```

## Sincronización de Datos
```typescript
// Hook para manejo offline
const useOfflineSync = () => {
  const [isOffline, setIsOffline] = useState(false);
  const [pendingChanges, setPendingChanges] = useState([]);
  
  const syncWhenOnline = async () => {
    if (!isOffline && pendingChanges.length > 0) {
      for (const change of pendingChanges) {
        await syncChange(change);
      }
      setPendingChanges([]);
    }
  };
  
  return { isOffline, pendingChanges, syncWhenOnline };
};
```

## Notificaciones Push
```typescript
// Registro de notificaciones
const registerForPushNotifications = async () => {
  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: 'PUBLIC_KEY'
  });
  
  // Enviar subscription al servidor
  await fetch('/api/v3/notifications/subscribe', {
    method: 'POST',
    body: JSON.stringify(subscription)
  });
};
```

## Instalación Promovida
```tsx
<PWAInstallPrompt>
  <Button onClick={promptInstall}>
    📱 Instalar VITAL 3.0 en tu dispositivo
  </Button>
</PWAInstallPrompt>
```

## Optimizaciones PWA
- **Lazy loading** de rutas
- **Preload** de recursos críticos
- **Cache** estratégico de assets
- **Compresión** de imágenes
- **Minificación** de recursos