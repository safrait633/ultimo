# Paso 14. Sistema de Notificaciones y Logging

## 🔔 Sistema de Notificaciones

### Tipos de Notificaciones
- **Info:** Autoguardado exitoso, paciente creado
- **Éxito:** Examen completado, informe generado
- **Advertencia:** Campos obligatorios vacíos, datos inconsistentes  
- **Error:** Fallo de conexión, error de validación
- **Crítico:** Signos vitales alarmantes, emergencias

### Componentes UI
```tsx
<NotificationContainer>
  <Toast type="success" autoClose={3000}>
    Examen guardado exitosamente
  </Toast>
  <Toast type="warning" persistent>
    Revisar presión arterial: 180/100 mmHg
  </Toast>
</NotificationContainer>
```

### Posicionamiento
- **Desktop:** Esquina superior derecha
- **Mobile:** Parte superior, ancho completo
- **Tablet:** Esquina superior derecha, adaptativo

## 📊 Sistema de Logging

### Logs del Sistema
- Autenticación de usuarios
- Creación/edición de pacientes
- Exámenes médicos realizados
- Errores de sistema
- Performance metrics

### Estructura de Log
```typescript
interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'critical';
  userId: number;
  action: string;
  details: Record<string, any>;
  ipAddress: string;
  userAgent: string;
}
```

### Auditoría Médica
- Registro de todas las acciones sobre pacientes
- Trazabilidad de cambios en exámenes
- Historial de accesos a datos sensibles
- Compliance con regulaciones médicas

## 🎯 Implementación

### Frontend (React)
```tsx
// Hook para notificaciones
const { showNotification } = useNotifications();

// Mostrar notificación
showNotification({
  type: 'success',
  message: 'Paciente creado exitosamente',
  autoClose: 3000
});
```

### Backend (Node.js)
```typescript
// Logger service
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'vital-error.log', level: 'error' }),
    new winston.transports.File({ filename: 'vital-combined.log' })
  ]
});

// Registrar acción médica
logger.info('Patient examination created', {
  userId: req.user.id,
  patientId: examination.patientId,
  specialty: examination.specialty,
  timestamp: new Date()
});
```

## 🌍 Multiidioma para Notificaciones

### Mensajes por Idioma
```typescript
const notifications = {
  es: {
    patient_created: 'Paciente creado exitosamente',
    exam_saved: 'Examen guardado',
    vital_signs_warning: 'Revisar signos vitales'
  },
  ca: {
    patient_created: 'Pacient creat amb èxit',
    exam_saved: 'Examen desat',
    vital_signs_warning: 'Revisar signes vitals'
  },
  fr: {
    patient_created: 'Patient créé avec succès',
    exam_saved: 'Examen sauvegardé',
    vital_signs_warning: 'Vérifier les signes vitaux'
  }
};
```