# Paso 15. Sistema de Impresión y Exportación de Informes

## 📄 Generación de Informes PDF

### Tipos de Informes
- **Informe de Consulta:** Resumen del examen médico
- **Receta Médica:** Prescripciones y medicamentos
- **Derivación:** Referencias a especialistas
- **Certificado Médico:** Aptitud laboral, incapacidades
- **Informe Completo:** Historial médico detallado

### Componentes de Impresión
```tsx
// Generador de PDF
<ReportGenerator 
  type="consultation"
  patient={selectedPatient}
  examination={currentExamination}
  template="standard"
/>

// Vista previa
<PrintPreview>
  <ReportTemplate />
</PrintPreview>
```

### Plantillas de Informes
- **Estándar:** Logo hospital, datos básicos
- **Detallada:** Incluye gráficos y tablas
- **Resumen:** Versión compacta
- **Oficial:** Con sellos y firmas digitales

## 🖨️ Funciones de Impresión

### Configuración de Página
- **Formato:** A4, Letter, Legal
- **Orientación:** Vertical, Horizontal
- **Márgenes:** Configurables
- **Encabezado/Pie:** Personalizable

### Exportación Múltiple
- **PDF:** Informe principal
- **Excel:** Datos tabulares
- **Word:** Plantillas editables
- **Imagen:** JPG/PNG para redes

## 📊 Datos a Incluir

### Información del Hospital
```typescript
interface HospitalInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
  logo: string;
  license: string;
}
```

### Información del Médico
```typescript
interface DoctorInfo {
  firstName: string;
  lastName: string;
  specialty: string;
  licenseNumber: string;
  signature: string;
}
```

### Datos del Paciente
```typescript
interface PatientInfo {
  fullName: string;
  age: number;
  gender: string;
  documentNumber: string;
  phone?: string;
  address?: string;
}
```

### Contenido Médico
```typescript
interface MedicalContent {
  examDate: Date;
  chiefComplaint: string;
  vitalSigns: VitalSigns;
  physicalExam: Record<string, any>;
  diagnosis: string;
  treatment: string;
  recommendations: string[];
  followUp?: string;
}
```

## 🌍 Plantillas Multiidioma

### Estructura de Plantilla
```html
<!-- Encabezado -->
<header>
  <h1>{{report.title.es}}</h1>
  <p>{{hospital.name}}</p>
</header>

<!-- Contenido Principal -->
<main>
  <section>
    <h2>{{labels.patient_data.es}}</h2>
    <p>{{patient.fullName}}</p>
  </section>
  
  <section>
    <h2>{{labels.examination.es}}</h2>
    <p>{{examination.chiefComplaint}}</p>
  </section>
</main>
```

### Etiquetas por Idioma
```typescript
const reportLabels = {
  es: {
    report_title: 'Informe Médico',
    patient_data: 'Datos del Paciente',
    examination: 'Examen Médico',
    diagnosis: 'Diagnóstico',
    treatment: 'Tratamiento'
  },
  ca: {
    report_title: 'Informe Mèdic',
    patient_data: 'Dades del Pacient',
    examination: 'Examen Mèdic',
    diagnosis: 'Diagnòstic',
    treatment: 'Tractament'
  },
  fr: {
    report_title: 'Rapport Médical',
    patient_data: 'Données du Patient',
    examination: 'Examen Médical',
    diagnosis: 'Diagnostic',
    treatment: 'Traitement'
  }
};
```

## ⚡ Optimizaciones

### Performance
- Generación asíncrona de PDF
- Cache de plantillas
- Compresión de imágenes
- Paginación automática

### UX
- Vista previa inmediata
- Indicador de progreso
- Descarga automática
- Opción de email directo