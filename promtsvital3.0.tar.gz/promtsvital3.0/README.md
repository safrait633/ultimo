# VITAL 3.0 — Prompts para Desarrollo

Aquí se recopilan los prompts paso a paso para crear una plataforma médica moderna VITAL 3.0 sin usar IA en la etapa inicial.

## Principios Fundamentales
- Sin IA/AI al inicio (solo plantillas y formularios manuales)
- Interfaz glassmorphism oscuro (estilo oscuro, inspirado en Apple Health Record)
- Soporte para todos los dispositivos: desktop, tablet, mobile
- SPA: todo en una ventana, sin transiciones innecesarias
- Página de inicio: registro, login, recuperación de contraseña, dashboard médico
- Especialidades — solo stubs, se agregan según necesidad
- Base de datos: MySQL
- Frontend: React 18 + TypeScript + Tailwind CSS + Vite
- Backend: Node.js + Express + TypeScript

## Idiomas Soportados (Orden de Prioridad)
1. 🇪🇸 **Español** (principal)
2. 🏴󠁥󠁳󠁣󠁴󠁿 **Catalán** (prioritario)
3. 🇫🇷 **Francés**
4. 🇬🇧 **Inglés**
5. 🇷🇺 **Ruso**

## Estructura
- 13+ pasos — cada paso en archivo separado/prompt
- Cada prompt describe una etapa o componente específico

---

## Lista de Pasos

### Funcionalidad Básica (MVP)
1. Arquitectura y stack tecnológico
2. Sistema de diseño y glassmorphism oscuro
3. Base de datos MySQL (esquema)
4. Autenticación: registro, login, recuperación de contraseña
5. Dashboard principal del médico (SPA)
6. Sistema de pacientes (búsqueda, agregar, anónimos)
7. Stubs para especialidades médicas
8. Sistema de plantillas de exámenes (sin IA)
9. Layout adaptativo para todos los dispositivos
10. Localización y multiidioma

### Funcionalidad Avanzada
11. Mapa del sitio y navegación
12. Gestión de estados y performance
13. Seguridad y validaciones
14. Sistema de notificaciones y logging
15. Sistema de impresión y exportación de informes
16. **Sistema de backup y recuperación**
17. **PWA (Progressive Web App) y modo offline**
18. **Testing y QA automatizado**
19. **Analíticas y métricas médicas**
20. **Deployment y DevOps**

### Funcionalidad Profesional
16. Sistema de signos vitales
17. Sistema de historial médico
18. Sistema de backup y recuperación
19. Sistema de roles y permisos
20. Aplicación web progresiva (PWA)

---

> Cada prompt — en archivo .md separado con descripción detallada y ejemplos.
> **Todos los prompts están en español con soporte multiidioma: ES → CA → FR → EN → RU**
> Se recomienda empezar con los pasos 1-10 (MVP), luego 11-15 (Avanzado), y finalmente 16-20 (Profesional).