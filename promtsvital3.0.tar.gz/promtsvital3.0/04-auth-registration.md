# Paso 4. Autenticación: registro, login, recuperación de contraseña

## Requisitos
- Página de inicio: opción entre registro, login, recuperación de contraseña
- Todo en una ventana (SPA)
- Sin IA/AI

## Componentes Principales
- RegistrationForm
- LoginForm
- PasswordRecoveryForm
- AuthLayout (layout unificado para auth)
- LanguageSelector (selector de idioma)

## UX/UI
- Mínimos campos para entrada/registro
- Validación en cliente y servidor (React Hook Form + Zod)
- Mensajes de error y éxito
- Botón "Mostrar/ocultar contraseña"
- Selector de idioma prominente

## Ejemplo de Interfaz
```
┌─────────────────────────────────────┐
│   VITAL 3.0          [ES|CA|FR|EN] │
│ ┌─────────────┐ ┌──────────────┐   │
│ │    Login    │ │  Registro    │   │
│ └─────────────┘ └──────────────┘   │
│ [Recuperar contraseña]             │
│                                    │
│ Formulario activo aquí...          │
└─────────────────────────────────────┘
```

## Campos de Registro
- Email (obligatorio)
- Contraseña (mínimo 8 caracteres)
- Nombre (obligatorio)
- Apellido (obligatorio)
- Idioma preferido (por defecto: ES)

## API Endpoints (backend)
- POST /api/v3/auth/register
- POST /api/v3/auth/login
- POST /api/v3/auth/recover
- POST /api/v3/auth/reset-password

## Validaciones Zod
```typescript
const RegisterSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  preferredLanguage: z.enum(['es', 'ca', 'fr', 'en', 'ru'])
});
```

## Multiidioma
- Formularios traducidos en tiempo real
- Mensajes de error localizados
- Emails de recuperación en idioma del usuario

## Notas
- Sin logins sociales
- JWT para sesiones
- Refresh tokens para seguridad
- Persistencia de idioma seleccionado