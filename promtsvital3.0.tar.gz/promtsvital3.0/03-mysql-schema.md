# Paso 3. Base de Datos MySQL (esquema)

## Tablas Principales
- users (médicos, administradores)
- patients (pacientes)
- anonymous_patients (anónimos)
- examinations (exámenes)
- examination_templates (plantillas)
- medical_specialties (especialidades — solo stubs)
- auto_saves (autoguardado)
- system_translations (traducciones multiidioma)

## Ejemplo de Esquema (fragmento)
```sql
CREATE DATABASE vital3_db 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE vital3_db;

# Paso 3. Base de Datos MySQL (esquema)

## Tablas Principales
- users (médicos, administradores)
- patients (pacientes)
- anonymous_patients (anónimos)
- examinations (exámenes)
- examination_templates (plantillas)
- medical_specialties (especialidades — solo stubs)
- auto_saves (autoguardado)

## Ejemplo de Esquema (fragmento)
```sql
CREATE DATABASE vital3_db 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE vital3_db;

-- Tabla de usuarios (médicos)
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  role ENUM('doctor','admin') DEFAULT 'doctor',
  specialty_id INT,
  language_preference ENUM('es','ca','fr','en','ru') DEFAULT 'es',
  is_active BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla de pacientes
CREATE TABLE patients (
  id INT PRIMARY KEY AUTO_INCREMENT,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  age INT,
  gender ENUM('male','female','other') DEFAULT 'other',
  birth_date DATE,
  document_number VARCHAR(50),
  phone VARCHAR(20),
  email VARCHAR(255),
  medical_history JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_patients_document (document_number),
  INDEX idx_patients_name (first_name, last_name)
);

-- Tabla de pacientes anónimos (temporales)
CREATE TABLE anonymous_patients (
  id INT PRIMARY KEY AUTO_INCREMENT,
  age INT,
  gender ENUM('male','female','other') DEFAULT 'other',
  birth_date DATE,
  expires_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de exámenes médicos
CREATE TABLE examinations (
  id INT PRIMARY KEY AUTO_INCREMENT,
  exam_code VARCHAR(20) UNIQUE,
  doctor_id INT NOT NULL,
  patient_id INT,
  anonymous_patient_id INT,
  specialty VARCHAR(50),
  chief_complaint TEXT,
  vital_signs JSON,
  physical_exam JSON,
  preliminary_diagnosis TEXT,
  final_diagnosis TEXT,
  treatment TEXT,
  recommendations TEXT,
  status ENUM('draft','completed','cancelled') DEFAULT 'draft',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME,
  FOREIGN KEY (doctor_id) REFERENCES users(id),
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (anonymous_patient_id) REFERENCES anonymous_patients(id)
);
```

## Especialidades (Solo Stubs)
```sql
-- Tabla de especialidades médicas (stubs iniciales)
CREATE TABLE medical_specialties (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name_es VARCHAR(100),
  name_ca VARCHAR(100),
  name_fr VARCHAR(100),
  name_en VARCHAR(100),
  slug VARCHAR(50) UNIQUE,
  icon VARCHAR(50),
  color VARCHAR(7),
  template_fields JSON,
  is_active BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insertar stubs básicos
INSERT INTO medical_specialties (name_es, name_ca, name_fr, name_en, slug, icon, color, is_active) VALUES
('Cardiología', 'Cardiologia', 'Cardiologie', 'Cardiology', 'cardiology', 'heart', '#DC2626', FALSE),
('Neurología', 'Neurologia', 'Neurologie', 'Neurology', 'neurology', 'brain', '#7C3AED', FALSE),
('Gastroenterología', 'Gastroenterologia', 'Gastroentérologie', 'Gastroenterology', 'gastroenterology', 'activity', '#059669', FALSE);
```

## Notas Importantes
- Sin campos de IA/AI
- Especialidades — solo stubs, agregar según necesidad
- Soporte multiidioma en nombres de especialidades
- Autoguardado temporal para recuperación de datos
- Índices optimizados para búsquedas médicas frecuentes
```

## Datos Iniciales (Especialidades Stub)
```sql
INSERT INTO medical_specialties (slug, name_es, name_ca, name_fr, name_en, name_ru, icon, color, is_active) VALUES
('cardiology', 'Cardiología', 'Cardiologia', 'Cardiologie', 'Cardiology', 'Кардиология', 'heart', '#DC2626', FALSE),
('neurology', 'Neurología', 'Neurologia', 'Neurologie', 'Neurology', 'Неврология', 'brain', '#7C3AED', FALSE),
('gastroenterology', 'Gastroenterología', 'Gastroenterologia', 'Gastroentérologie', 'Gastroenterology', 'Гастроэнтерология', 'activity', '#059669', FALSE);
```

## Notas
- Sin campos de IA/AI
- Especialidades — solo stubs, agregar por necesidad
- Soporte multiidioma: ES → CA → FR → EN → RU
- Índices optimizados para búsquedas médicas