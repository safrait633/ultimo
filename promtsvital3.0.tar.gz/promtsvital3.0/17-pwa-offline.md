# Paso 17. PWA (Progressive Web App) y Modo Offline

## 📱 Configuración PWA

### Manifest.json
```json
{
  "name": "VITAL 3.0 - Plataforma Médica",
  "short_name": "VITAL 3.0",
  "description": "Sistema médico profesional multiidioma",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#181A20",
  "theme_color": "#0066CC",
  "orientation": "any",
  "icons": [
    {
      "src": "/icons/vital-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icons/vital-512.png", 
      "sizes": "512x512",
      "type": "image/png"
    }
  ],
  "categories": ["medical", "health", "productivity"],
  "lang": "es"
}
```

### Service Worker
```typescript
// service-worker.ts
const CACHE_NAME = 'vital-v3.0.0';
const STATIC_CACHE = 'vital-static-v1';
const DYNAMIC_CACHE = 'vital-dynamic-v1';

// Archivos críticos para cache
const STATIC_ASSETS = [
  '/',
  '/static/css/main.css',
  '/static/js/main.js',
  '/manifest.json',
  '/icons/vital-192.png'
];

// Estrategia de cache
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/api/v3/')) {
    // API requests - Network First
    event.respondWith(networkFirst(event.request));
  } else {
    // Static assets - Cache First
    event.respondWith(cacheFirst(event.request));
  }
});
```

## 🔄 Funcionalidad Offline

### Datos Sincronizables
- **Exámenes en progreso:** Guardado local automático
- **Datos de pacientes:** Cache de pacientes recientes
- **Plantillas:** Plantillas utilizadas frecuentemente
- **Configuración:** Preferencias del usuario

### Estrategias de Sincronización
```typescript
interface SyncStrategy {
  // Network First: Intentar red, fallback a cache
  networkFirst: (request: Request) => Promise<Response>;
  
  // Cache First: Cache primero, fallback a red
  cacheFirst: (request: Request) => Promise<Response>;
  
  // Stale While Revalidate: Cache inmediato, actualizar en background
  staleWhileRevalidate: (request: Request) => Promise<Response>;
}
```

### Queue de Sincronización
```typescript
interface SyncQueue {
  id: string;
  type: 'examination_save' | 'patient_create' | 'template_update';
  data: any;
  timestamp: Date;
  attempts: number;
  status: 'pending' | 'syncing' | 'completed' | 'failed';
}
```

## 📊 Indicadores de Estado

### Estado de Conexión
```tsx
const ConnectionStatus = () => {
  const isOnline = useOnlineStatus();
  const pendingSync = usePendingSyncItems();
  
  return (
    <div className="connection-status">
      {isOnline ? (
        <Badge variant="success">
          🌐 Conectado {pendingSync > 0 && `(${pendingSync} pendientes)`}
        </Badge>
      ) : (
        <Badge variant="warning">
          📴 Modo Offline
        </Badge>
      )}
    </div>
  );
};
```

### Indicador de Sincronización
```tsx
const SyncIndicator = () => {
  const { t } = useTranslation();
  const { isSyncing, lastSync, pendingItems } = useSync();
  
  if (isSyncing) {
    return <Spinner size="sm">{t('syncing')}</Spinner>;
  }
  
  if (pendingItems > 0) {
    return (
      <Badge variant="warning">
        {pendingItems} {t('pending_sync')}
      </Badge>
    );
  }
  
  return (
    <Badge variant="success">
      {t('synced')} {formatDistanceToNow(lastSync)}
    </Badge>
  );
};
```

## 🔧 Instalación PWA

### Prompt de Instalación
```tsx
const InstallPWA = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstall, setShowInstall] = useState(false);
  
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstall(true);
    };
    
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);
  
  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setShowInstall(false);
      }
    }
  };
  
  if (!showInstall) return null;
  
  return (
    <Toast>
      <p>{t('install_pwa_message')}</p>
      <Button onClick={handleInstall}>{t('install')}</Button>
    </Toast>
  );
};
```

## 🌍 Multiidioma para PWA
```json
{
  "es": {
    "install_pwa": "Instalar VITAL 3.0",
    "install_pwa_message": "Instala VITAL en tu dispositivo para acceso rápido",
    "syncing": "Sincronizando...",
    "synced": "Sincronizado",
    "pending_sync": "pendientes",
    "offline_mode": "Modo sin conexión activo"
  },
  "ca": {
    "install_pwa": "Instal·lar VITAL 3.0",
    "install_pwa_message": "Instal·la VITAL al teu dispositiu per accés ràpid",
    "syncing": "Sincronitzant...",
    "synced": "Sincronitzat",
    "pending_sync": "pendents",
    "offline_mode": "Mode sense connexió actiu"
  }
}
```

## ⚡ Optimizaciones

### Preloading Inteligente
- Precargar datos de pacientes frecuentes
- Cache de plantillas más utilizadas
- Prefetch de especialidades activas

### Compresión de Datos
- Comprimir datos antes de almacenar en cache
- Optimizar imágenes para dispositivos móviles
- Minimizar payload de API responses