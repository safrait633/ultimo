# Paso 16. Sistema de Signos Vitales

## Requisitos
- Panel universal para signos vitales
- Cálculos automáticos (IMC, superficie corporal)
- Alertas automáticas por valores anormales
- Entrada rápida y validación

## Signos Vitales Principales
```typescript
interface VitalSigns {
  bloodPressure: {
    systolic: number;
    diastolic: number;
    unit: 'mmHg';
    timestamp: Date;
  };
  heartRate: {
    value: number;
    unit: 'bpm';
    rhythm: 'regular' | 'irregular';
  };
  temperature: {
    value: number;
    unit: 'celsius' | 'fahrenheit';
    site: 'oral' | 'rectal' | 'axillary' | 'tympanic';
  };
  respiratoryRate: {
    value: number;
    unit: 'rpm';
  };
  oxygenSaturation: {
    value: number;
    unit: '%';
    onAir: boolean;
    fiO2?: number;
  };
  weight: {
    value: number;
    unit: 'kg' | 'lb';
  };
  height: {
    value: number;
    unit: 'cm' | 'in';
  };
  bmi?: number; // Calculado automáticamente
  pain: {
    level: number; // 0-10
    scale: '0-10' | 'faces';
    location?: string;
  };
}
```

## Alertas Automáticas
```typescript
const vitalSignsAlerts = {
  hypertension: { systolic: '>140', diastolic: '>90' },
  hypotension: { systolic: '<90', diastolic: '<60' },
  tachycardia: { heartRate: '>100' },
  bradycardia: { heartRate: '<60' },
  fever: { temperature: '>37.5°C' },
  hypoxemia: { oxygenSaturation: '<95%' },
  underweight: { bmi: '<18.5' },
  overweight: { bmi: '>25' },
  obesity: { bmi: '>30' }
};
```

## Componente VitalSignsPanel
```tsx
<VitalSignsPanel
  values={vitalSigns}
  onChange={updateVitalSigns}
  showAlerts={true}
  quickEntry={true}
>
  <VitalSignInput 
    type="bloodPressure" 
    label="Presión Arterial"
    format="systolic/diastolic"
  />
  <VitalSignInput 
    type="heartRate"
    label="Frecuencia Cardíaca" 
  />
  <BMICalculator 
    weight={weight}
    height={height}
    autoCalculate={true}
  />
</VitalSignsPanel>
```

## Valores Normales por Edad
```typescript
const normalRanges = {
  adult: {
    systolic: [90, 140],
    diastolic: [60, 90],
    heartRate: [60, 100],
    temperature: [36.1, 37.2],
    respiratoryRate: [12, 20]
  },
  pediatric: {
    '0-1mo': { heartRate: [120, 160] },
    '1-12mo': { heartRate: [80, 140] },
    '1-3yr': { heartRate: [80, 130] }
  }
};
```

## Multiidioma
```typescript
const vitalSignsLabels = {
  es: {
    bloodPressure: 'Presión Arterial',
    heartRate: 'Frecuencia Cardíaca',
    temperature: 'Temperatura',
    weight: 'Peso',
    height: 'Altura'
  },
  ca: {
    bloodPressure: 'Pressió Arterial',
    heartRate: 'Freqüència Cardíaca',
    temperature: 'Temperatura',
    weight: 'Pes',
    height: 'Alçada'
  }
};
```