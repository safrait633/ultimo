# Paso 19. Sistema de Roles y Permisos

## Requisitos
- Roles diferenciados (Doctor, Admin, Enfermera)
- Permisos granulares por función
- Control de acceso a pacientes
- Auditoría de acciones por rol

## Tipos de Roles
```typescript
enum UserRole {
  ADMIN = 'admin',           // Acceso completo
  DOCTOR = 'doctor',         // Pacientes y exámenes
  NURSE = 'nurse',           // Signos vitales, asistencia
  RESIDENT = 'resident',     // Limitado, supervisado
  RECEPTIONIST = 'receptionist' // Solo pacientes básico
}
```

## Permisos por Rol
```typescript
const rolePermissions = {
  admin: [
    'users.create', 'users.edit', 'users.delete',
    'patients.all', 'examinations.all',
    'settings.modify', 'backup.create'
  ],
  doctor: [
    'patients.create', 'patients.edit', 'patients.view',
    'examinations.create', 'examinations.edit', 
    'reports.generate', 'templates.create'
  ],
  nurse: [
    'patients.view', 'vitalsigns.edit',
    'examinations.assist', 'appointments.manage'
  ],
  resident: [
    'patients.view', 'examinations.create.supervised',
    'reports.view'
  ],
  receptionist: [
    'patients.create', 'patients.edit.basic',
    'appointments.schedule'
  ]
};
```

## Componente de Control de Acceso
```tsx
<RequirePermission permission="patients.create">
  <CreatePatientButton />
</RequirePermission>

<RoleBasedComponent 
  allowedRoles={['doctor', 'admin']}
>
  <ExaminationForm />
</RoleBasedComponent>
```

## Middleware de Autorización
```typescript
const requirePermission = (permission: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const userRole = req.user.role;
    const userPermissions = rolePermissions[userRole];
    
    if (!userPermissions.includes(permission)) {
      return res.status(403).json({ 
        error: 'Insufficient permissions' 
      });
    }
    
    next();
  };
};
```

## Gestión de Usuarios (Admin)
```tsx
<UserManagement>
  <UserList 
    roles={['doctor', 'nurse', 'resident']}
    showInactive={true}
  />
  <CreateUserForm 
    defaultRole="doctor"
    requireApproval={true}
  />
  <RoleEditor 
    customPermissions={true}
  />
</UserManagement>
```

## Auditoría por Roles
- Registro de todas las acciones
- Filtrado por rol de usuario
- Reportes de actividad
- Alertas de acciones sospechosas