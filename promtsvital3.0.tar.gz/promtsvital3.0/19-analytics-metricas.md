# Paso 19. Analíticas y Métricas Médicas

## 📊 Dashboard de Analíticas

### Métricas Clave (KPIs)
- **Productividad Médica:**
  - Exámenes por día/semana/mes
  - Tiempo promedio por examen
  - Especialidades más utilizadas
  - Plantillas más populares

- **Calidad de Datos:**
  - Exámenes completos vs incompletos
  - Campos obligatorios faltantes
  - Tasa de corrección/edición

- **Uso del Sistema:**
  - Usuarios activos diarios/mensuales
  - Tiempo de sesión promedio
  - Funciones más utilizadas
  - Dispositivos de acceso

### Componentes de Visualización
```tsx
// Analytics Dashboard
const AnalyticsDashboard = () => {
  const { t } = useTranslation();
  const { data: metrics } = useAnalyticsData();
  
  return (
    <div className="analytics-grid">
      <MetricCard
        title={t('examinations_today')}
        value={metrics.examinationsToday}
        trend={metrics.examinationsTrend}
        icon="activity"
      />
      
      <MetricCard
        title={t('average_exam_time')}
        value={`${metrics.avgExamTime} min`}
        trend={metrics.timeTrend}
        icon="clock"
      />
      
      <ChartCard title={t('examinations_by_specialty')}>
        <SpecialtyChart data={metrics.specialtyData} />
      </ChartCard>
      
      <ChartCard title={t('monthly_activity')}>
        <TimeSeriesChart data={metrics.monthlyData} />
      </ChartCard>
    </div>
  );
};
```

## 📈 Métricas en Tiempo Real

### WebSocket para Updates Live
```typescript
// Real-time metrics service
class MetricsService {
  private ws: WebSocket;
  
  constructor() {
    this.ws = new WebSocket('ws://localhost:3001/metrics');
    this.setupEventListeners();
  }
  
  private setupEventListeners() {
    this.ws.addEventListener('message', (event) => {
      const metric = JSON.parse(event.data);
      this.updateMetric(metric);
    });
  }
  
  private updateMetric(metric: MetricUpdate) {
    // Actualizar store de métricas
    useMetricsStore.getState().updateMetric(metric);
  }
}
```

### Eventos Trackables
```typescript
interface TrackableEvent {
  type: 'examination_created' | 'patient_added' | 'template_used' | 'report_generated';
  userId: number;
  timestamp: Date;
  metadata: {
    specialty?: string;
    templateId?: string;
    duration?: number;
    deviceType?: string;
  };
}

// Tracking hook
const useTracking = () => {
  const track = (event: TrackableEvent) => {
    // Enviar evento a backend
    fetch('/api/v3/analytics/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(event)
    });
  };
  
  return { track };
};
```

## 📊 Reportes Automáticos

### Reporte Semanal por Email
```typescript
interface WeeklyReport {
  period: { start: Date; end: Date };
  summary: {
    totalExaminations: number;
    uniquePatients: number;
    avgExaminationTime: number;
    topSpecialties: Array<{ name: string; count: number }>;
  };
  trends: {
    examinationsChange: number; // % vs semana anterior
    efficiencyChange: number;   // % cambio en tiempo promedio
  };
  recommendations: string[];
}

// Generador de reportes
const generateWeeklyReport = async (doctorId: number): Promise<WeeklyReport> => {
  const endDate = new Date();
  const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
  
  const examinations = await getExaminationsByPeriod(doctorId, startDate, endDate);
  const previousWeekExams = await getExaminationsByPeriod(doctorId, 
    new Date(startDate.getTime() - 7 * 24 * 60 * 60 * 1000), 
    startDate
  );
  
  return {
    period: { start: startDate, end: endDate },
    summary: calculateSummary(examinations),
    trends: calculateTrends(examinations, previousWeekExams),
    recommendations: generateRecommendations(examinations)
  };
};
```

## 🎯 Métricas de Performance

### Core Web Vitals
```typescript
// Performance monitoring
const PerformanceMonitor = () => {
  useEffect(() => {
    // Largest Contentful Paint
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'largest-contentful-paint') {
          sendMetric('LCP', entry.startTime);
        }
      }
    }).observe({ entryTypes: ['largest-contentful-paint'] });
    
    // First Input Delay
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'first-input') {
          sendMetric('FID', entry.processingStart - entry.startTime);
        }
      }
    }).observe({ entryTypes: ['first-input'] });
    
    // Cumulative Layout Shift
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'layout-shift' && !entry.hadRecentInput) {
          sendMetric('CLS', entry.value);
        }
      }
    }).observe({ entryTypes: ['layout-shift'] });
  }, []);
  
  return null;
};
```

### Métricas Médicas Específicas
```typescript
interface MedicalMetrics {
  // Eficiencia Clínica
  avgTimePerExamination: number;
  examinationsPerHour: number;
  templateUsageRate: number;
  
  // Calidad de Datos
  completeExaminationsRate: number;
  dataAccuracyScore: number;
  missingFieldsRate: number;
  
  // Productividad
  dailyExaminationGoal: number;
  goalAchievementRate: number;
  peakProductivityHours: number[];
  
  // Satisfacción del Usuario
  averageSessionDuration: number;
  bounceRate: number;
  featureAdoptionRate: Record<string, number>;
}
```

## 📱 Analytics por Dispositivo

### Segmentación por Tipo de Dispositivo
```typescript
const DeviceAnalytics = () => {
  const deviceMetrics = useDeviceMetrics();
  
  return (
    <div className="device-analytics">
      <h3>{t('usage_by_device')}</h3>
      
      <div className="device-grid">
        <DeviceCard
          type="desktop"
          usage={deviceMetrics.desktop}
          avgSessionTime={deviceMetrics.desktopSessionTime}
          icon="monitor"
        />
        
        <DeviceCard
          type="tablet"
          usage={deviceMetrics.tablet}
          avgSessionTime={deviceMetrics.tabletSessionTime}
          icon="tablet"
        />
        
        <DeviceCard
          type="mobile"
          usage={deviceMetrics.mobile}
          avgSessionTime={deviceMetrics.mobileSessionTime}
          icon="smartphone"
        />
      </div>
    </div>
  );
};
```

## 🌍 Analytics Multiidioma

### Métricas por Idioma
```typescript
interface LanguageMetrics {
  language: 'es' | 'ca' | 'fr' | 'en' | 'ru';
  userCount: number;
  usagePercentage: number;
  avgSessionDuration: number;
  preferredFeatures: string[];
}

const LanguageAnalytics = () => {
  const { t } = useTranslation();
  const languageData = useLanguageMetrics();
  
  return (
    <div className="language-analytics">
      <h3>{t('usage_by_language')}</h3>
      
      <LanguageChart data={languageData} />
      
      <div className="language-insights">
        {languageData.map(lang => (
          <LanguageInsightCard
            key={lang.language}
            language={lang.language}
            metrics={lang}
          />
        ))}
      </div>
    </div>
  );
};
```

## 🔄 Exportación de Datos

### Export Dashboard
```tsx
const ExportControls = () => {
  const { t } = useTranslation();
  
  const exportOptions = [
    { format: 'PDF', icon: 'file-text' },
    { format: 'Excel', icon: 'table' },
    { format: 'CSV', icon: 'database' },
    { format: 'JSON', icon: 'code' }
  ];
  
  return (
    <div className="export-controls">
      <h4>{t('export_analytics')}</h4>
      
      <div className="export-options">
        {exportOptions.map(option => (
          <Button
            key={option.format}
            variant="outline"
            onClick={() => exportData(option.format)}
          >
            <Icon name={option.icon} />
            {option.format}
          </Button>
        ))}
      </div>
    </div>
  );
};
```