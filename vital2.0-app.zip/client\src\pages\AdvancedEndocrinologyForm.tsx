// Temporary clean file - will replace original
export default function TempComponent() {
  return <div>Temp</div>;
}