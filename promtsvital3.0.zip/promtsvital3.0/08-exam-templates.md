# Paso 8. Sistema de Plantillas de Exámenes (sin IA)

## Requisitos
- Solo plantillas manuales (sin IA)
- Selección rápida de plantilla por especialidad
- Posibilidad de editar plantilla
- Plantillas de ejemplo para 2-3 especialidades (stubs)

## Estructura de Plantilla
```json
{
  "id": "cardio-chest-pain",
  "name": "Dolor Torácico",
  "specialty": "cardiology",
  "type": "quick",
  "estimatedTime": 8,
  "usageCount": 0,
  "fields": [
    {
      "id": "chief_complaint", 
      "type": "textarea", 
      "label": {
        "es": "Motivo de consulta",
        "ca": "Motiu de consulta",
        "fr": "Motif de consultation"
      },
      "required": true,
      "placeholder": {
        "es": "Describe el motivo principal de la consulta",
        "ca": "Descriu el motiu principal de la consulta"
      }
    },
    {
      "id": "pain_characteristics", 
      "type": "select", 
      "label": {
        "es": "Características del dolor",
        "ca": "Característiques del dolor",
        "fr": "Caractéristiques de la douleur"
      },
      "options": [
        {"value": "oppressive", "label": {"es": "Opresivo", "ca": "Opressiu"}},
        {"value": "stabbing", "label": {"es": "Punzante", "ca": "Punxent"}}
      ],
      "required": true
    }
  ]
}
```

## Tipos de Campos
- **textarea:** Texto largo (quejas, historia)
- **select:** Opciones predefinidas
- **checkbox:** Múltiples opciones
- **number:** Valores numéricos
- **date:** Fechas
- **vital-signs:** Signos vitales especiales

## Plantillas de Ejemplo

### Cardiología
```json
{
  "templates": [
    {
      "name": "Dolor Torácico",
      "fields": ["chief_complaint", "pain_characteristics", "vital_signs", "ecg"]
    },
    {
      "name": "Hipertensión Control",
      "fields": ["blood_pressure", "symptoms", "medication_compliance"]
    }
  ]
}
```

### Neurología
```json
{
  "templates": [
    {
      "name": "Cefalea",
      "fields": ["headache_type", "location", "intensity", "triggers"]
    },
    {
      "name": "Mareos",
      "fields": ["dizziness_type", "balance_tests", "nystagmus"]
    }
  ]
}
```

## Componentes
- ExamTemplateSelector
- ExamTemplateEditor (stub inicial)
- TemplateFieldRenderer
- QuickTemplateButton

## Selector de Plantillas
```tsx
<TemplateSelector 
  specialty="cardiology"
  onSelect={(template) => loadTemplate(template)}
>
  <TemplateCard 
    name="Dolor Torácico"
    estimatedTime="8 min"
    usageCount={156}
  />
</TemplateSelector>
```

## Sistema de Campos Dinámicos
```typescript
interface TemplateField {
  id: string;
  type: 'textarea' | 'select' | 'checkbox' | 'number' | 'date';
  label: Record<Language, string>;
  placeholder?: Record<Language, string>;
  required: boolean;
  options?: Array<{
    value: string;
    label: Record<Language, string>;
  }>;
  validation?: {
    min?: number;
    max?: number;
    regex?: string;
  };
}
```

## Gestión de Plantillas
- **Crear:** Formulario visual para nuevas plantillas
- **Editar:** Modificar plantillas existentes
- **Clonar:** Duplicar y personalizar
- **Exportar:** Compartir plantillas entre médicos

## API Endpoints
- GET /api/v3/examination-templates?specialty=cardiology
- POST /api/v3/examination-templates (crear)
- PUT /api/v3/examination-templates/:id (editar)
- DELETE /api/v3/examination-templates/:id (eliminar)

## Notas
- Sin IA/AI
- Solo llenado y selección manual
- Validación automática de campos requeridos
- Plantillas multiidioma completas