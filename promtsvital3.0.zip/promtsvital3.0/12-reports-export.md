# Шаг 12. Система печати и экспорта отчётов

## Требования
- Генерация PDF отчётов
- Печать осмотров и рецептов
- Экспорт в различные форматы (PDF, Word, Excel)
- Шаблоны документов с логотипом клиники

## Компоненты
- ReportGenerator
- PrintManager
- PDFExporter
- DocumentTemplates

## API endpoints
- GET /api/v3/reports/:id/pdf
- GET /api/v3/reports/:id/print
- POST /api/v3/reports/generate

## Примечания
- Поддержка русских шрифтов в PDF
- Возможность настройки шаблонов
- Водяные знаки для защиты