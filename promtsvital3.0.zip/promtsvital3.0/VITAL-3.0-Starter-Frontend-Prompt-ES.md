# 🏥 VITAL 3.0 - Prompt Inicial para Frontend HTML+CSS+JS
## 📋 Aplicación de Una Sola Página para Plataforma Médica

> **OBJETIVO**: Crear el frontend inicial de VITAL 3.0 en HTML+CSS+JavaScript puro en un solo archivo con funcionalidad completa y diseño en estilo Apple Health + glassmorphism.

---

## 🎯 PROMPT PRINCIPAL

```
Crea una aplicación médica de una sola página VITAL 3.0 en HTML+CSS+JavaScript puro:

🎨 DISEÑO Y ESTILÍSTICA:
- Estilo Apple Health Records con efectos glassmorphism
- Tarjetas transparentes con efecto de desenfoque y iluminación
- Gradientes suaves, sombras y esquinas redondeadas
- Tipografía moderna con jerarquía clara
- Animaciones fluidas y transiciones entre secciones

📱 ESTRUCTURA DE LA APLICACIÓN:
- Página de landing con presentación de la plataforma
- Formulario de registro especializado para médicos
- Formulario de autorización/login para médicos
- Panel de control principal (dashboard)
- Módulo de gestión de pacientes completo
- Módulo de examen médico con especialidades
- Módulo de signos vitales y mediciones
- Módulo de diagnósticos y patologías
- Generador de reportes médicos profesionales
- Módulo de configuraciones y perfil médico
- Sistema de notificaciones médicas
- Módulo de búsqueda avanzada

🔧 REQUISITOS TÉCNICOS:
- Un archivo HTML con CSS y JavaScript integrados
- Diseño responsive para tablets y móviles
- Cambio entre secciones sin recarga
- Almacenamiento local de datos en localStorage
- Validación de formularios y manejo de errores
- Simulación de trabajo con datos médicos
```

---

## 📖 DESCRIPCIÓN DETALLADA DE PÁGINAS

### 🏠 1. PÁGINA DE LANDING
**Descripción**: Página de presentación de la plataforma VITAL 3.0
**Elementos**:
- Encabezado con logo y navegación
- Banner principal con descripción de ventajas de la plataforma
- Sección con características clave (rapidez, seguridad, comodidad)
- Demostración de interfaz con capturas o animaciones
- Testimonios de especialistas médicos
- Llamada a la acción con botón "Comenzar a trabajar"
- Pie de página con información de contacto

### 🔐 2. FORMULARIO DE REGISTRO MÉDICO
**Descripción**: Registro especializado para profesionales de la salud
**Elementos**:
- Campos específicos médicos: nombre, apellidos, número de colegiado
- Especialidad médica principal y secundarias
- Centro de trabajo actual y anteriores
- Número de licencia médica y fecha de expedición
- Años de experiencia y formación académica
- Validación de credenciales médicas
- Subida de documentos de acreditación
- Verificación por email institucional
- Términos y condiciones específicos para uso médico
- Política de privacidad de datos médicos

### 🔑 3. PÁGINA DE AUTORIZACIÓN/LOGIN
**Descripción**: Acceso al sistema para médicos registrados
**Elementos**:
- Formulario de acceso con email y contraseña
- Botón "Iniciar sesión" con animación de carga
- Enlace "¿Olvidaste tu contraseña?"
- Interruptor "Recordarme"
- Acceso rápido con credenciales demo
- Sistema de doble factor de autenticación (opcional)
- Recuperación de contraseña por email

### 🏥 4. PANEL PRINCIPAL (DASHBOARD)
**Descripción**: Centro de control principal para el médico
**Elementos**:
- Saludo con nombre del médico y fecha actual
- Acciones rápidas: "Nuevo examen", "Buscar paciente", "Reportes"
- Estadísticas del día: cantidad de exámenes, pacientes, tiempo
- Calendario con citas programadas
- Lista de pacientes recientes con acceso rápido
- Notificaciones y recordatorios
- Botón de llamada de emergencia o ayuda

### 👤 5. MÓDULO DE GESTIÓN DE PACIENTES
**Descripción**: Sistema completo de administración de pacientes
**Elementos**:
- Barra de búsqueda avanzada con múltiples criterios
- Filtros por: nombre, documento, edad, sexo, última visita
- Botón "Agregar nuevo paciente" con formulario completo
- Formulario de paciente anónimo para emergencias
- Lista de pacientes con información resumida y foto
- Historial médico detallado de cada paciente
- Sistema de etiquetas y categorización de pacientes
- Exportación de datos de pacientes
- Integración con sistemas externos de identificación

### 🩺 6. MÓDULO DE EXAMEN MÉDICO
**Descripción**: Interfaz principal para realizar exámenes médicos
**Elementos**:
- Información completa del paciente en cabecera
- Selector dinámico de especialidades médicas
- Formulario de motivo de consulta y sintomatología
- Sección de anamnesis con campos estructurados
- Examen físico por sistemas (cardiovascular, respiratorio, etc.)
- Exploración específica según especialidad seleccionada
- Campos para observaciones generales
- Sistema de plantillas rápidas por especialidad
- Autoguardado continuo con indicador visual
- Vista previa del examen en tiempo real

### 💓 7. MÓDULO DE SIGNOS VITALES
**Descripción**: Registro y monitoreo de constantes vitales
**Elementos**:
- Campos para presión arterial (sistólica/diastólica)
- Frecuencia cardíaca y ritmo
- Temperatura corporal con unidades
- Saturación de oxígeno
- Frecuencia respiratoria
- Peso y altura con cálculo automático de IMC
- Escalas de dolor (0-10)
- Nivel de conciencia (Glasgow)
- Gráficos históricos de evolución
- Alertas automáticas por valores anormales

### 🔍 8. MÓDULO DE DIAGNÓSTICOS
**Descripción**: Sistema de diagnósticos y codificación médica
**Elementos**:
- Buscador de diagnósticos por síntomas
- Integración con códigos CIE-10
- Diagnóstico principal y secundarios
- Diagnósticos diferenciales
- Pronóstico y evolución esperada
- Recomendaciones terapéuticas
- Plan de seguimiento
- Derivaciones a especialistas
- Incapacidades laborales si aplica

### 📊 9. GENERADOR DE REPORTES MÉDICOS
**Descripción**: Sistema profesional de generación de informes médicos
**Elementos**:
- Tipos de reporte: consulta, diagnóstico, interconsulta, certificado
- Plantillas personalizables según especialidad
- Editor de texto enriquecido para informes
- Inserción automática de datos del paciente y examen
- Membrete personalizable con datos del médico y centro
- Firma digital del médico
- Códigos QR para verificación de autenticidad
- Exportación a PDF con marca de agua
- Historial completo de reportes generados
- Sistema de búsqueda en reportes anteriores

### 🔔 10. MÓDULO DE NOTIFICACIONES
**Descripción**: Sistema de alertas y recordatorios médicos
**Elementos**:
- Notificaciones de citas programadas
- Alertas de valores críticos en signos vitales
- Recordatorios de seguimiento de pacientes
- Notificaciones de resultados pendientes
- Alertas de medicación y contraindicaciones
- Sistema de prioridades (urgente, normal, informativo)
- Historial de notificaciones
- Configuración de preferencias de alertas

### 🔍 11. MÓDULO DE BÚSQUEDA AVANZADA
**Descripción**: Sistema de búsqueda inteligente en toda la plataforma
**Elementos**:
- Búsqueda global por pacientes, diagnósticos, reportes
- Filtros avanzados por fecha, especialidad, médico
- Búsqueda por códigos CIE-10
- Búsqueda de patologías y síntomas
- Resultados categorizados y paginados
- Exportación de resultados de búsqueda
- Historial de búsquedas frecuentes

### ⚙️ 12. CONFIGURACIONES Y PERFIL MÉDICO
**Descripción**: Panel de configuración personal y profesional del médico
**Elementos**:
- Perfil profesional con foto, datos de contacto y credenciales
- Configuración de especialidades y subespecialidades
- Plantillas personalizadas de examen por especialidad
- Configuraciones de interfaz (tema, idioma, tamaño de fuente)
- Preferencias de notificaciones y alertas
- Configuración de autoguardado y sincronización
- Gestión de firma digital y sellos profesionales
- Configuraciones de privacidad y seguridad
- Cambio de contraseña y autenticación de dos factores
- Exportación e importación de configuraciones
- Integración con sistemas hospitalarios externos
- Soporte técnico y centro de ayuda

---

## 🎨 DETALLES DE DISEÑO GLASSMORPHISM

### 🌟 EFECTOS VISUALES
- **Transparencia**: backdrop-filter con efecto blur
- **Bordes**: Marcos finos semitransparentes
- **Sombras**: Sombras suaves multinivel para profundidad
- **Gradientes**: Gradientes apenas perceptibles en tarjetas
- **Reflejos**: Imitación de superficie de vidrio

### 📱 ADAPTABILIDAD
- **Tablet**: Interfaz principal con funcionalidad completa
- **Móvil**: Navegación simplificada, ocultación de elementos secundarios
- **Desktop**: Paneles expandidos e información adicional

---

## ⚡ REQUISITOS FUNCIONALES

### 🔄 NAVEGACIÓN
- Transiciones fluidas entre secciones sin recarga
- Migas de pan para entender ubicación actual
- Botón "Atrás" en cada sección
- Teclas de acceso rápido para acceso rápido

### 💾 GUARDADO DE DATOS
- Guardado automático cada 3 segundos
- Indicador de estado de guardado
- Advertencia ante pérdida de conexión
- Recuperación de datos no guardados al recargar

### ✅ VALIDACIÓN
- Verificación de campos obligatorios en tiempo real
- Validación de formato email, teléfono, fecha de nacimiento
- Verificación de corrección de indicadores médicos
- Mensajes de error comprensibles

### 📊 DATOS DEMO
- Perfiles listos de pacientes de prueba
- Ejemplos de formularios médicos completados
- Muestras de reportes para demostración
- Simulación de trabajo con base de datos

---

## 🚀 DETALLES TÉCNICOS

### 📋 ESTRUCTURA DEL ARCHIVO
```
index.html
├── <head> - metatags, conexión de fuentes
├── <style> - todos los estilos CSS incluyendo glassmorphism
├── <body> - marcado de todas las páginas
└── <script> - toda la funcionalidad JavaScript
```

### 🎛️ FUNCIONES JAVASCRIPT
- Gestión del estado de la aplicación
- Cambio entre páginas
- Procesamiento de formularios y validación
- Almacenamiento local de datos
- Animaciones y efectos de interfaz
- Simulación de peticiones API

### 📱 BREAKPOINTS RESPONSIVE
- Móvil: hasta 768px
- Tablet: 768px - 1024px
- Desktop: desde 1024px

---

## ✅ RESULTADO

Después de ejecutar este prompt obtendrás:
- Prototipo completamente funcional de una página de VITAL 3.0
- Diseño moderno en estilo Apple Health con glassmorphism
- Todas las páginas y funciones necesarias para trabajo médico
- Interfaz adaptativa para diferentes dispositivos
- Base lista para desarrollo posterior

> 💡 **Nota**: Esta es la versión inicial para demostración del concepto. Más tarde se pueden agregar funciones más complejas, integración con base de datos real y módulos médicos expandidos.