# Paso 20. Deployment y DevOps

## 🚀 Estrategia de Deployment

### Ambientes
```
Development → Testing → Staging → Production
     ↓           ↓        ↓          ↓
   Local     CI/CD     Pre-prod   Live
```

### Configuración por Ambiente
```typescript
// config/environments.ts
interface Environment {
  name: string;
  apiUrl: string;
  dbHost: string;
  redis: {
    host: string;
    port: number;
  };
  features: {
    analytics: boolean;
    debugging: boolean;
    maintenance: boolean;
  };
}

export const environments: Record<string, Environment> = {
  development: {
    name: 'development',
    apiUrl: 'http://localhost:3001',
    dbHost: 'localhost',
    redis: { host: 'localhost', port: 6379 },
    features: { analytics: false, debugging: true, maintenance: false }
  },
  
  staging: {
    name: 'staging',
    apiUrl: 'https://api-staging.vital3.com',
    dbHost: 'staging-db.vital3.com',
    redis: { host: 'staging-redis.vital3.com', port: 6379 },
    features: { analytics: true, debugging: true, maintenance: true }
  },
  
  production: {
    name: 'production',
    apiUrl: 'https://api.vital3.com',
    dbHost: 'prod-db.vital3.com',
    redis: { host: 'prod-redis.vital3.com', port: 6379 },
    features: { analytics: true, debugging: false, maintenance: false }
  }
};
```

## 🐳 Docker Configuration

### Frontend Dockerfile
```dockerfile
# Frontend Dockerfile
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Backend Dockerfile
```dockerfile
# Backend Dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

USER node
EXPOSE 3001

CMD ["node", "dist/index.js"]
```

### Docker Compose
```yaml
# docker-compose.yml
version: '3.8'

services:
  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - backend
    environment:
      - REACT_APP_API_URL=http://backend:3001
  
  backend:
    build: ./backend
    ports:
      - "3001:3001"
    depends_on:
      - mysql
      - redis
    environment:
      - DB_HOST=mysql
      - DB_USER=vital_user
      - DB_PASSWORD=${DB_PASSWORD}
      - REDIS_HOST=redis
  
  mysql:
    image: mysql:8.0
    ports:
      - "3306:3306"
    environment:
      - MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}
      - MYSQL_DATABASE=vital3_db
      - MYSQL_USER=vital_user
      - MYSQL_PASSWORD=${DB_PASSWORD}
    volumes:
      - mysql_data:/var/lib/mysql
      - ./init-db:/docker-entrypoint-initdb.d
  
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  mysql_data:
  redis_data:
```

## ☁️ Cloud Deployment

### AWS Infrastructure
```yaml
# aws-infrastructure.yml (CloudFormation)
AWSTemplateFormatVersion: '2010-09-09'
Description: 'VITAL 3.0 Infrastructure'

Resources:
  # VPC
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: 10.0.0.0/16
      EnableDnsHostnames: true
      Tags:
        - Key: Name
          Value: VITAL-VPC

  # ECS Cluster
  ECSCluster:
    Type: AWS::ECS::Cluster
    Properties:
      ClusterName: vital3-cluster
      CapacityProviders:
        - FARGATE
        - FARGATE_SPOT

  # RDS MySQL
  Database:
    Type: AWS::RDS::DBInstance
    Properties:
      DBInstanceIdentifier: vital3-mysql
      Engine: mysql
      EngineVersion: '8.0'
      DBInstanceClass: db.t3.micro
      AllocatedStorage: 20
      StorageType: gp2
      DBName: vital3_db
      MasterUsername: !Ref DBUsername
      MasterUserPassword: !Ref DBPassword
      VPCSecurityGroups:
        - !Ref DatabaseSecurityGroup

  # ElastiCache Redis
  RedisCluster:
    Type: AWS::ElastiCache::CacheCluster
    Properties:
      CacheNodeType: cache.t3.micro
      Engine: redis
      NumCacheNodes: 1
      VpcSecurityGroupIds:
        - !Ref RedisSecurityGroup
```

### Kubernetes Deployment
```yaml
# k8s/deployment.yml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vital3-frontend
  labels:
    app: vital3-frontend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: vital3-frontend
  template:
    metadata:
      labels:
        app: vital3-frontend
    spec:
      containers:
      - name: frontend
        image: vital3/frontend:latest
        ports:
        - containerPort: 80
        resources:
          requests:
            memory: "64Mi"
            cpu: "50m"
          limits:
            memory: "128Mi"
            cpu: "100m"

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vital3-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: vital3-backend
  template:
    metadata:
      labels:
        app: vital3-backend
    spec:
      containers:
      - name: backend
        image: vital3/backend:latest
        ports:
        - containerPort: 3001
        env:
        - name: DB_HOST
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: host
        - name: DB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: password
```

## 🔄 CI/CD Pipeline

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy VITAL 3.0

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run tests
        run: |
          npm run test:unit
          npm run test:integration
          npm run lint
          npm run type-check
      
      - name: Build application
        run: npm run build

  deploy-staging:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    environment: staging
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: eu-west-1
      
      - name: Build and push Docker images
        run: |
          docker build -t vital3/frontend:${{ github.sha }} ./frontend
          docker build -t vital3/backend:${{ github.sha }} ./backend
          
          aws ecr get-login-password | docker login --username AWS --password-stdin $ECR_REGISTRY
          docker push $ECR_REGISTRY/vital3/frontend:${{ github.sha }}
          docker push $ECR_REGISTRY/vital3/backend:${{ github.sha }}
      
      - name: Deploy to ECS
        run: |
          aws ecs update-service --cluster vital3-staging --service frontend-service --force-new-deployment
          aws ecs update-service --cluster vital3-staging --service backend-service --force-new-deployment

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    environment: production
    
    steps:
      - name: Deploy to production
        run: |
          # Similar deployment pero a producción
          # Con aprobación manual requerida
          echo "Deploying to production..."
```

## 📊 Monitoring y Observabilidad

### Health Checks
```typescript
// backend/src/health.ts
import express from 'express';

const router = express.Router();

// Health check básico
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: process.env.APP_VERSION,
    environment: process.env.NODE_ENV
  });
});

// Health check detallado
router.get('/health/detailed', async (req, res) => {
  const checks = {
    database: await checkDatabase(),
    redis: await checkRedis(),
    memory: process.memoryUsage(),
    uptime: process.uptime()
  };
  
  const isHealthy = Object.values(checks).every(check => 
    check.status === 'healthy'
  );
  
  res.status(isHealthy ? 200 : 503).json({
    status: isHealthy ? 'healthy' : 'unhealthy',
    checks,
    timestamp: new Date().toISOString()
  });
});
```

### Logging Configuration
```typescript
// logger.ts
import winston from 'winston';

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: {
    service: 'vital3-backend',
    version: process.env.APP_VERSION
  },
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.Console({
      format: winston.format.simple()
    })
  ]
});

export default logger;
```

## 🔧 Configuración de Nginx

### nginx.conf
```nginx
# nginx.conf
server {
    listen 80;
    server_name vital3.com www.vital3.com;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;
    
    # Frontend
    location / {
        root /usr/share/nginx/html;
        try_files $uri $uri/ /index.html;
        
        # Cache static assets
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
    
    # API proxy
    location /api/ {
        proxy_pass http://backend:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```