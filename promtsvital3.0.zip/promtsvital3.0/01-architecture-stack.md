# Paso 1. Arquitectura y Stack VITAL 3.0

## Objetivos
- Mínimas transiciones, todo en una ventana (SPA)
- Sin IA/AI al inicio
- Soporte para desktop, tablet, mobile
- Stack moderno y estructura modular

## Tecnologías
- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, Zustand, React Hook Form, Zod, Radix UI, shadcn/ui, Lucide React
- **Backend:** Node.js, Express, TypeScript, MySQL
- **UI:** Glassmorphism oscuro (estilo oscuro, Apple Health Record)
- **Localización:** react-i18next

## Estructura del Proyecto
```
/ (root)
  promtsvital3.0/         # Prompts y documentación
  VITAL3.0-frontend/      # Parte cliente (SPA)
  VITAL3.0-backend/       # Parte servidor (API)
```

## Principios
- Arquitectura limpia, separación por capas
- Todos los escenarios principales — sin IA
- Facilidad de expansión (especialidades, plantillas, roles)
- Adaptabilidad para todos los dispositivos

## Idiomas Soportados (Orden de Prioridad)
1. 🇪🇸 Español (principal)
2. 🏴󠁥󠁳󠁣󠁴󠁿 Catalán (prioritario) 
3. 🇫🇷 Francés
4. 🇬🇧 Inglés
5. 🇷🇺 Ruso