# Paso 7. Especialidades — Stubs

## Requisitos
- Al inicio — solo stubs para especialidades
- Agregar especialidades reales según necesidad
- Color, icono, nombre (multiidioma)

## Estructura de Stub
```json
{
  "id": 1,
  "slug": "cardiology",
  "name": {
    "es": "Cardiología",
    "ca": "Cardiologia", 
    "fr": "Cardiologie",
    "en": "Cardiology",
    "ru": "Кардиология"
  },
  "icon": "heart",
  "color": "#DC2626",
  "template_fields": {},
  "is_active": false,
  "description": {
    "es": "Especialidad del corazón y sistema cardiovascular",
    "ca": "Especialitat del cor i sistema cardiovascular",
    "fr": "Spécialité du cœur et système cardiovasculaire"
  }
}
```

## Especialidades Stub Iniciales
1. **Cardiología** - `heart` - `#DC2626`
2. **Neurología** - `brain` - `#7C3AED`
3. **Gastroenterología** - `activity` - `#059669`
4. **Endocrinología** - `zap` - `#D97706`
5. **Dermatología** - `droplet` - `#EC4899`
6. **Traumatología** - `bone` - `#1D4ED8`

## Componentes
- SpecialtyStubCard
- SpecialtyList (solo stubs)
- SpecialtySelector (para formularios)

## Ejemplo de Tarjeta Stub
```tsx
<SpecialtyStubCard 
  specialty="cardiology"
  color="#DC2626"
  icon="heart"
  isActive={false}
  onClick={() => showComingSoon()}
>
  <Badge>Próximamente</Badge>
</SpecialtyStubCard>
```

## Estados de Especialidad
- **Stub:** Solo visual, sin funcionalidad
- **En Desarrollo:** Con formularios básicos
- **Activa:** Completamente funcional
- **Deshabilitada:** Temporalmente fuera de servicio

## Implementación Gradual
```typescript
interface SpecialtyImplementationPlan {
  phase1: ['cardiology'];           // MVP
  phase2: ['neurology', 'gastro'];  // Expansión
  phase3: ['endocrinology', 'dermatology']; // Completo
  phase4: ['traumatology', 'pediatrics'];   // Avanzado
}
```

## Multiidioma para Stubs
```sql
INSERT INTO medical_specialties (slug, name_es, name_ca, name_fr, name_en, name_ru, icon, color, is_active) VALUES
('cardiology', 'Cardiología', 'Cardiologia', 'Cardiologie', 'Cardiology', 'Кардиология', 'heart', '#DC2626', FALSE),
('neurology', 'Neurología', 'Neurologia', 'Neurologie', 'Neurology', 'Неврология', 'brain', '#7C3AED', FALSE),
('gastroenterology', 'Gastroenterología', 'Gastroenterologia', 'Gastroentérologie', 'Gastroenterology', 'Гастроэнтерология', 'activity', '#059669', FALSE);
```

## UX para Stubs
- Indicador visual "Próximamente"
- Click muestra modal informativo
- Roadmap de implementación visible
- Posibilidad de "solicitar especialidad"

## Notas
- Validación solo en slug y name
- Campos template_fields vacíos
- Campos y plantillas reales — más tarde
- Fácil activación cuando se implemente