# Paso 6. Sistema de Pacientes (búsqueda, agregar, anónimos)

## Requisitos
- Búsqueda rápida por nombre, documento, teléfono
- Autocompletado después de 2 caracteres
- Agregar nuevo paciente sin transición
- Paciente anónimo — en 1 clic
- Historial de últimos pacientes

## Componentes Principales
- PatientQuickSearch
- PatientQuickCreate
- AnonymousPatientCreate
- RecentPatientsList
- PatientCard (para visualización)

## Búsqueda Inteligente
```typescript
interface SearchOptions {
  query: string;
  filters: {
    gender?: 'male' | 'female' | 'other';
    ageRange?: { min: number; max: number };
    hasDocument?: boolean;
  };
  limit: number;
}
```

## Formulario Rápido de Paciente
```tsx
<PatientQuickCreate>
  <Input name="firstName" required />
  <Input name="lastName" required />
  <NumberInput name="age" min={0} max={120} />
  <Select name="gender" options={genderOptions} />
  <Input name="documentNumber" optional />
  <PhoneInput name="phone" optional />
</PatientQuickCreate>
```

## Paciente Anónimo
- Solo edad y género
- Código autogenerado (ANON-001, ANON-002...)
- Expiración automática después de 30 días
- Sin datos personales almacenados

## API Endpoints
- GET /api/v3/patients/search?q=...&limit=10
- GET /api/v3/patients/recent?limit=5
- POST /api/v3/patients (crear paciente)
- POST /api/v3/patients/anonymous (crear anónimo)
- GET /api/v3/patients/:id (obtener paciente)

## Estados de Búsqueda
- **Vacío:** Sin resultados de búsqueda
- **Buscando:** Indicador de carga
- **Resultados:** Lista de pacientes encontrados
- **Error:** Mensaje de error de búsqueda

## Validaciones
```typescript
const PatientSchema = z.object({
  firstName: z.string().min(2).max(50),
  lastName: z.string().min(2).max(50),
  age: z.number().min(0).max(120),
  gender: z.enum(['male', 'female', 'other']),
  documentNumber: z.string().optional(),
  phone: z.string().regex(/^[+]?[\d\s-()]+$/).optional(),
  email: z.string().email().optional()
});
```

## Multiidioma
```typescript
const patientLabels = {
  es: {
    firstName: 'Nombre',
    lastName: 'Apellido',
    age: 'Edad',
    gender: 'Género',
    document: 'Documento',
    phone: 'Teléfono'
  },
  ca: {
    firstName: 'Nom',
    lastName: 'Cognom',
    age: 'Edat',
    gender: 'Gènere',
    document: 'Document',
    phone: 'Telèfon'
  },
  fr: {
    firstName: 'Prénom',
    lastName: 'Nom',
    age: 'Âge',
    gender: 'Genre',
    document: 'Document',
    phone: 'Téléphone'
  }
};
```

## UX Optimizado
- Debounce en búsqueda (300ms)
- Scroll infinito para muchos resultados
- Shortcuts de teclado (Ctrl+F para buscar)
- Vista previa rápida de datos del paciente

## Notas
- Sin IA/AI
- Mínimo de campos obligatorios
- UX: todo rápido, sin pasos innecesarios
- Soporte para todos los dispositivos