# Paso 10. Localización y Multiidioma

## Requisitos
- Soporte prioritario: español, catalán, francés, inglés, ruso
- Selector de idioma en header
- Autodetección del idioma del navegador  
- Almacenamiento de traducciones en JSON
- Uso de react-i18next

## Orden de Prioridad de Idiomas
1. 🇪🇸 **Español** (principal)
2. 🏴󠁥󠁳󠁣󠁴󠁿 **Catalán** (prioritario)
3. 🇫🇷 **Francés**
4. 🇬🇧 **Inglés**
5. 🇷🇺 **Ruso**

## Estructura de Traducciones
```json
// locales/es/common.json
{
  "login": "Iniciar sesión",
  "register": "Registrarse", 
  "dashboard": "Panel principal",
  "patient": "Paciente",
  "examination": "Examen",
  "specialty": "Especialidad",
  "save": "Guardar",
  "cancel": "Cancelar",
  "search": "Buscar",
  "new": "Nuevo"
}

// locales/ca/common.json  
{
  "login": "Iniciar sessió",
  "register": "Registrar-se",
  "dashboard": "Panell principal", 
  "patient": "Pacient",
  "examination": "Examen",
  "specialty": "Especialitat",
  "save": "Desar",
  "cancel": "Cancel·lar",
  "search": "Cercar",
  "new": "Nou"
}

// locales/fr/common.json
{
  "login": "Se connecter",
  "register": "S'inscrire",
  "dashboard": "Tableau de bord",
  "patient": "Patient", 
  "examination": "Examen",
  "specialty": "Spécialité",
  "save": "Sauvegarder",
  "cancel": "Annuler",
  "search": "Rechercher",
  "new": "Nouveau"
}
```

## Configuración de i18next
```typescript
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Importar traducciones
import esCommon from '../locales/es/common.json';
import esAuth from '../locales/es/auth.json';
import esMedical from '../locales/es/medical.json';

import caCommon from '../locales/ca/common.json';
import caAuth from '../locales/ca/auth.json';
import caMedical from '../locales/ca/medical.json';

const resources = {
  es: {
    common: esCommon,
    auth: esAuth,
    medical: esMedical
  },
  ca: {
    common: caCommon,
    auth: caAuth,
    medical: caMedical
  },
  fr: { /*...*/ },
  en: { /*...*/ },
  ru: { /*...*/ }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'es',
    debug: false,
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage']
    },
    
    interpolation: {
      escapeValue: false
    }
  });
```

## Componente Selector de Idioma
```tsx
import { useTranslation } from 'react-i18next';

const LanguageSelector = () => {
  const { i18n } = useTranslation();
  
  const languages = [
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'ca', name: 'Català', flag: '🏴󠁥󠁳󠁣󠁴󠁿' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'ru', name: 'Русский', flag: '🇷🇺' }
  ];
  
  return (
    <Select
      value={i18n.language}
      onValueChange={(lang) => i18n.changeLanguage(lang)}
    >
      {languages.map(lang => (
        <SelectItem key={lang.code} value={lang.code}>
          {lang.flag} {lang.name}
        </SelectItem>
      ))}
    </Select>
  );
};
```

## Hook Personalizado
```typescript
export const useLanguage = () => {
  const { i18n } = useTranslation();
  
  const changeLanguage = (language: string) => {
    i18n.changeLanguage(language);
    localStorage.setItem('vital-language', language);
  };
  
  const getCurrentLanguage = () => i18n.language;
  
  const getAvailableLanguages = () => ['es', 'ca', 'fr', 'en', 'ru'];
  
  return {
    currentLanguage: i18n.language,
    changeLanguage,
    getCurrentLanguage,
    getAvailableLanguages
  };
};
```

## Traducciones Médicas
```json
// locales/es/medical.json
{
  "vital_signs": "Signos vitales",
  "blood_pressure": "Presión arterial",
  "heart_rate": "Frecuencia cardíaca",
  "temperature": "Temperatura",
  "chief_complaint": "Motivo de consulta",
  "physical_exam": "Examen físico",
  "diagnosis": "Diagnóstico",
  "treatment": "Tratamiento",
  "recommendations": "Recomendaciones"
}

// locales/ca/medical.json
{
  "vital_signs": "Signes vitals",
  "blood_pressure": "Pressió arterial", 
  "heart_rate": "Freqüència cardíaca",
  "temperature": "Temperatura",
  "chief_complaint": "Motiu de consulta",
  "physical_exam": "Examen físic",
  "diagnosis": "Diagnòstic",
  "treatment": "Tractament",
  "recommendations": "Recomanacions"
}
```

## Formatos por Región
```typescript
const formatters = {
  es: {
    date: new Intl.DateTimeFormat('es-ES'),
    number: new Intl.NumberFormat('es-ES'),
    currency: new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' })
  },
  ca: {
    date: new Intl.DateTimeFormat('ca-ES'),
    number: new Intl.NumberFormat('ca-ES'),
    currency: new Intl.NumberFormat('ca-ES', { style: 'currency', currency: 'EUR' })
  },
  fr: {
    date: new Intl.DateTimeFormat('fr-FR'),
    number: new Intl.NumberFormat('fr-FR'),
    currency: new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' })
  }
};
```

## Componentes
- LanguageSelector
- i18n.ts (inicialización)
- TranslationProvider
- useLanguage (hook personalizado)

## Notas
- Todas las claves — en inglés, valores — en idiomas necesarios
- Traducciones para todos los componentes UI principales
- Persistencia en localStorage
- Detección automática del idioma del navegador
- Fallback al español si el idioma no está disponible