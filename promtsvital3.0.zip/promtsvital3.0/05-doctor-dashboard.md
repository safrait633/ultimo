# Paso 5. Dashboard Principal del Médico (SPA)

## Requisitos
- Después del login — directamente al dashboard médico
- Todo en una ventana, sin transiciones
- Estilo glassmorphism oscuro
- Acciones rápidas: nuevo examen, buscar paciente, informes
- Estado de autoguardado
- Adaptabilidad para todos los dispositivos

## Ejemplo de Layout
```
┌──────────────────────────────────────────────────────┐
│ VITAL 3.0   [🔍 Buscar] [Autoguardado ✓] [ES|CA|FR] │
├──────────────────────────────────────────────────────┤
│ [➕ Nuevo Examen] [👤 Paciente] [📊 Informes]       │
├──────────────────────────────────────────────────────┤
│ Panel Izquierdo       │ Área Principal               │
│ • Acciones Rápidas    │ • Formulario de Examen       │
│ • Pacientes Recientes │ • Vista Previa del Informe   │
│ • Plantillas          │ • Selector de Especialidades │
│ • Especialidades:     │                              │
│   ○ Cardiología      │                              │
│   ○ Neurología       │                              │
│   ○ Gastroenterología│                              │
└──────────────────────────────────────────────────────┘
```

## Componentes Principales
- DoctorDashboard
- QuickActions
- PatientQuickSearch
- ExaminationForm (stub inicial)
- ReportPreview (stub inicial)
- SpecialtySelector
- RecentPatientsList

## Acciones Rápidas
- **Nuevo Examen:** Inicia examen desde cero
- **Buscar Paciente:** Búsqueda inteligente con autocompletar
- **Paciente Anónimo:** Crea paciente anónimo en 1 clic
- **Plantillas:** Acceso a plantillas predefinidas
- **Informes:** Historial de informes generados

## Estados del Dashboard
- **Vacío:** Sin paciente seleccionado
- **Con Paciente:** Datos del paciente visibles
- **En Examen:** Formulario activo
- **Autoguardando:** Indicador de guardado automático

## Multiidioma
- Interfaz completa traducida
- Especialidades en idioma seleccionado
- Mensajes contextuales localizados

## Navegación Contextual
```typescript
// Estados de navegación
type DashboardState = 
  | 'overview'          // Vista general
  | 'new-examination'   // Nuevo examen
  | 'patient-search'    // Búsqueda de paciente
  | 'reports'          // Informes
  | 'settings';        // Configuración
```

## Notas
- Sin IA/AI
- Todos los datos — a través de Zustand store
- Autoguardado cada 3 segundos
- Transiciones suaves con Framer Motion
- Responsive: desktop, tablet, mobile