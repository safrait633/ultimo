# Paso 2. Sistema de Diseño y Glassmorphism Oscuro

## Principios de Diseño
- Estilo oscuro (oscuro), inspirado en Apple Health Record
- Efectos glassmorphism: transparencia, blur, sombras suaves
- Paleta de colores para medicina
- Soporte para desktop, tablet, mobile

## Colores
- primary: #0066CC (azul)
- success: #10B981 (verde)
- warning: #F59E0B (amarillo)
- danger: #EF4444 (rojo)
- neutral: #6B7280 (gris)
- fondo: #181A20 (oscuro)

## Especialidades por Color
- cardiología: #DC2626 (rojo)
- neurología: #7C3AED (púrpura)
- gastroenterología: #059669 (verde esmeralda)
- endocrinología: #D97706 (naranja)
- dermatología: #EC4899 (rosa)
- traumatología: #1D4ED8 (azul)

## Componentes
- GlassmorphismCard (tarjeta universal)
- SpecialtyCard (tarjeta de especialidad)
- TopBar, Sidebar, AutoSaveIndicator
- Botones, inputs, formularios con efectos glassmorphism

## Tipografía
- font-primary: Inter
- font-mono: JetBrains Mono

## Ejemplo de Uso
```tsx
<GlassmorphismCard>
  <h2>Título</h2>
  <p>Contenido...</p>
</GlassmorphismCard>
```

## Adaptabilidad
- Layout para todos los dispositivos (desktop, tablet, mobile)
- UI touch-friendly

## Idiomas en UI
- **Español:** Cardiología, Neurología, Gastroenterología
- **Catalán:** Cardiologia, Neurologia, Gastroenterologia  
- **Francés:** Cardiologie, Neurologie, Gastroentérologie
- **Inglés:** Cardiology, Neurology, Gastroenterology