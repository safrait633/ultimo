# Paso 11. Mapa del Sitio y Navegación

## Estructura de Navegación VITAL 3.0

### 🗺️ Mapa del Sitio Completo

```
VITAL 3.0 (SPA)
├── 🔐 Autenticación
│   ├── Página de Inicio (Login/Registro/Recuperar)
│   ├── Registro de Médico
│   ├── Login
│   └── Recuperar Contraseña
│
├── 🏥 Dashboard Principal (Médico)
│   ├── Panel Principal
│   │   ├── Acciones Rápidas
│   │   ├── Pacientes Recientes
│   │   ├── Plantillas Favoritas
│   │   └── Estadísticas del Día
│   │
│   ├── 👤 Gestión de Pacientes
│   │   ├── Búsqueda Rápida
│   │   ├── Crear Paciente
│   │   ├── Paciente Anónimo
│   │   ├── Lista de Pacientes
│   │   └── Historial Médico
│   │
│   ├── 📋 Exámenes Médicos
│   │   ├── Nuevo Examen
│   │   ├── Seleccionar Especialidad
│   │   ├── Formulario Dinámico
│   │   ├── Autoguardado
│   │   └── Vista Previa del Informe
│   │
│   ├── 🩺 Especialidades
│   │   ├── Lista de Especialidades (Stubs)
│   │   ├── Cardiología (Stub)
│   │   ├── Neurología (Stub)
│   │   ├── Gastroenterología (Stub)
│   │   └── [Agregar más...]
│   │
│   ├── 📊 Informes y Reportes
│   │   ├── Generar PDF
│   │   ├── Vista Previa
│   │   ├── Historial de Informes
│   │   └── Plantillas de Informes
│   │
│   └── ⚙️ Configuración
│       ├── Perfil del Médico
│       ├── Preferencias de Idioma
│       ├── Plantillas Personalizadas
│       └── Configuración de Autoguardado
│
└── 👨‍💼 Panel Admin (Futuro)
    ├── Gestión de Usuarios
    ├── Estadísticas Globales
    ├── Configuración del Sistema
    └── Backup y Mantenimiento
```

### 🧭 Navegación por Contexto

#### Navegación Principal (Siempre Visible)
- **Header:** Logo, Búsqueda de Pacientes, Notificaciones, Perfil, Idioma
- **Sidebar:** Acciones Rápidas, Especialidades, Plantillas, Configuración
- **Footer:** Estado de Autoguardado, Versión, Ayuda

#### Breadcrumbs Contextuales
```
Dashboard > Nuevo Examen > Cardiología > Dolor Torácico
Dashboard > Pacientes > Juan Pérez > Historial
Dashboard > Informes > Examen #P001 > Vista Previa
```

### 🔄 Flujos de Usuario Principales

#### Flujo 1: Examen Rápido
```
Dashboard → Nuevo Examen → Seleccionar/Crear Paciente → Especialidad → Formulario → Guardar/Imprimir
```

#### Flujo 2: Búsqueda de Paciente
```
Dashboard → Búsqueda → Seleccionar Paciente → Ver Historial → Nuevo Examen
```

#### Flujo 3: Plantilla Rápida
```
Dashboard → Plantillas → Seleccionar → Auto-rellenar Formulario → Completar → Guardar
```

### 📱 Navegación Responsive

#### Desktop (>1024px)
- Sidebar completo visible
- Header expandido con todas las opciones
- 3 columnas: Sidebar + Contenido + Panel Derecho

#### Tablet (768px-1024px)
- Sidebar colapsable
- Header compacto
- 2 columnas: Contenido + Panel Lateral

#### Mobile (<768px)
- Navigation drawer (hamburger menu)
- Header mínimo
- 1 columna: Stack vertical

### 🎯 Estados de Navegación

#### Estados Activos
- Página actual destacada en sidebar
- Breadcrumbs activos
- Indicador de progreso en formularios

#### Estados de Carga
- Skeleton loading para listas
- Spinner para acciones
- Progress bar para uploads

#### Estados de Error
- 404 para páginas no encontradas
- Mensajes de error contextual
- Botones de "Reintentar"